package app.screenertest.page;

import java.awt.Component;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.util.Assert;

import app.screenertest.datamanager.FileStorageManager;

public class CompanyPage {

	WebDriver driver;
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	
	public CompanyPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebDriver downloadExcel(String opfolderpath, String[] securitydata) 
	{
		int dload=0;
		try {
			dload =new FileStorageManager().getCountOfFilesFromPath(opfolderpath,".xlsx");   
			
			int i=1;
			do
			{
				if(i<=3)
				{
					driver.get("https://www.screener.in/company/"+securitydata[i]+"/");
					
				}
				if(i>3) {
					driver.get("https://www.screener.in/company/"+securitydata[i-3]+"/COSOLIDATED/");
					//System.out.println("https://www.screener.in/company/"+securitydata[i-3]+"/COSOLIDATED/");
				}
				if(driver.getTitle().contains("Error 404: Page Not Found - Screener")){
					System.out.println("	ERROR : "+driver.getCurrentUrl()+" : "+driver.getTitle());
				}
				else
				{
				System.out.println("	INFO : "+driver.getCurrentUrl()+" : "+driver.getTitle());
				}
				i++;
				
			}while(driver.getTitle().contains("Error 404: Page Not Found - Screener") && i<=6);
			if(driver==null)
			{
				return driver;
			}
			WebDriverWait wait = new WebDriverWait(driver,10 );
			String xpath = "//button[@aria-label='Export to Excel']";
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
			driver.findElement(By.xpath(xpath)).click();
			//driver.findElement(By.xpath("div[@id='top']/div/div/button/span")).click();
			int retry=0;
			while(new FileStorageManager().getCountOfFilesFromPath(opfolderpath,".xlsx")!=dload+1 && retry<30)
			{
				Thread.sleep(1000);
				retry++;
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.print("	WARNING : "+e.getLocalizedMessage());
			return null;
		}
		return this.driver;
	}
	
}